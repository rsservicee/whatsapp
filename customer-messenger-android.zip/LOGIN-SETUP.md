# লগইন সিস্টেম সেটআপ

1. Firebase Console → নতুন প্রজেক্ট → **Authentication → Sign-in method → Email/Password চালু করুন।**
2. **আগে** Authentication → Users → **Add user**: ইমেইল `admin@customermessenger.app`, নিজের শক্ত পাসওয়ার্ড দিন। (এটা সবার আগে করতে হবে।)
3. **Firestore Database** তৈরি করুন (Production mode) → **Rules** ট্যাবে `firestore.rules`-এর লেখা পেস্ট করে **Publish** দিন।
4. Project settings → Web app (`</>`) যোগ করুন → `apiKey` ও `projectId` কপি করুন।
5. `app/src/main/assets/auth/firebase-config.js`-এ `apiKey`, `projectId`, `waNumber` বসান।
6. অ্যাডমিন সাইটের `firebase-config.js`-এও একই `apiKey` ও `projectId` বসান।
7. অ্যাডমিন সাইটে লগইন করে ইউজার তৈরি করুন, WhatsApp-এ কাস্টমারকে ইউজারনেম/পাসওয়ার্ড পাঠান।
