package com.customermessenger.app

import org.json.JSONObject
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder

/** chrome.storage.local-এর বদলে: প্রতিটি key আলাদা ফাইলে (বড় ফাইল "att" বারবার লিখতে না হয়)। */
class Store(base: File) {
    private val dir = File(base, "store").apply { mkdirs() }

    private fun file(k: String) = File(dir, URLEncoder.encode(k, "UTF-8") + ".json")

    @Synchronized
    fun get(keys: List<String>?): String {
        val names = keys ?: (dir.listFiles() ?: emptyArray())
            .filter { it.name.endsWith(".json") }
            .map { URLDecoder.decode(it.name.removeSuffix(".json"), "UTF-8") }
        val sb = StringBuilder("{")
        var first = true
        for (k in names) {
            val f = file(k)
            if (!f.exists()) continue
            if (!first) sb.append(',')
            first = false
            sb.append(JSONObject.quote(k)).append(':').append(f.readText())
        }
        return sb.append('}').toString()
    }

    @Synchronized
    fun put(k: String, json: String) {
        val f = file(k)
        val t = File(dir, f.name + ".tmp")
        t.writeText(json)
        if (!t.renameTo(f)) {
            f.delete()
            t.renameTo(f)
        }
    }

    @Synchronized
    fun remove(k: String) {
        file(k).delete()
    }
}
