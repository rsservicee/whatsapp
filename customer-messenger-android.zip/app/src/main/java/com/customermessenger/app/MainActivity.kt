package com.customermessenger.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var ui: WebView
    private lateinit var wa: WebView
    private lateinit var auth: WebView
    private lateinit var btnUi: Button
    private lateinit var btnWa: Button
    private lateinit var store: Store
    private lateinit var shimSrc: String
    private lateinit var loader: WebViewAssetLoader
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var showingWa = false

    private val uiUrl = "https://appassets.androidplatform.net/assets/ext/popup.html"
    private val waUrl = "https://web.whatsapp.com/"
    private val authUrl = "https://appassets.androidplatform.net/assets/auth/login.html"
    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private val allowedFiles = setOf("content.js", "bridge-main.js", "wppconnect-wa.js")

    private fun asset(name: String): String =
        assets.open("ext/$name").bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WebView.setWebContentsDebuggingEnabled(true)

        store = Store(filesDir)
        shimSrc = asset("cm-shim.js")
        loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        wa = makeWebView(false)
        ui = makeWebView(true)
        setupWa()
        setupUi()
        setupAuth()

        val frame = FrameLayout(this)
        frame.addView(wa, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(ui, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        btnUi = Button(this).apply { text = "📋 মেসেজার"; setBackgroundColor(Color.TRANSPARENT); setOnClickListener { show(false) } }
        btnWa = Button(this).apply { text = "💬 WhatsApp"; setBackgroundColor(Color.TRANSPARENT); setOnClickListener { show(true) } }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF0B3A33.toInt())
            addView(btnUi, LinearLayout.LayoutParams(0, dp(52), 1f))
            addView(btnWa, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val host = FrameLayout(this)
        host.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        host.addView(auth, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(host)
        show(false)
        startKeepAlive()

        ui.loadUrl(uiUrl)
        auth.loadUrl(authUrl)
        wa.loadUrl(waUrl)
    }

    private fun show(whatsapp: Boolean) {
        showingWa = whatsapp
        (if (whatsapp) wa else ui).bringToFront()
        btnUi.setTextColor(if (whatsapp) Color.WHITE else 0xFFF5C84B.toInt())
        btnWa.setTextColor(if (whatsapp) 0xFFF5C84B.toInt() else Color.WHITE)
    }

    private fun startKeepAlive() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        try {
            val i = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWebView(fromUi: Boolean): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Native(fromUi), "__cmNative")
        return w
    }

    // ---------- WhatsApp Web ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWa() {
        val s = wa.settings
        s.userAgentString = desktopUa
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wa, true)
        wa.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null && url.startsWith("https://web.whatsapp.com")) injectContent()
            }
        }
    }

    // এক্সটেনশনের content_scripts-এর মতো: প্রতিটি WhatsApp পেজ লোডের পর content.js চালু করা
    private fun injectContent() {
        val sb = StringBuilder()
        sb.append("(function(){var m=document.querySelector('meta[name=viewport]');")
            .append("if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}")
            .append("m.setAttribute('content','width=1100');})();\n")
        sb.append(shimSrc).append("\n;")
        sb.append("if(!window.__cm){(function(){\n").append(asset("content.js")).append("\n})();}\n0;")
        wa.evaluateJavascript(sb.toString(), null)
    }

    // ---------- লগইন (assets/auth/login.html) ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupAuth() {
        auth = WebView(this)
        auth.setBackgroundColor(0xFF0B3A33.toInt())
        auth.settings.javaScriptEnabled = true
        auth.settings.domStorageEnabled = true
        auth.addJavascriptInterface(AuthNative(), "__authNative")
        auth.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.let { loader.shouldInterceptRequest(it.url) }
        }
    }

    inner class AuthNative {
        @JavascriptInterface
        fun ok() {
            runOnUiThread { auth.visibility = View.GONE }
        }

        @JavascriptInterface
        fun lock() {
            runOnUiThread {
                auth.visibility = View.VISIBLE
                auth.bringToFront()
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            if (!u.startsWith("https://wa.me/")) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                } catch (e: Exception) {
                }
            }
        }
    }

    // ---------- মূল UI (popup.html + background.js) ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupUi() {
        ui.setBackgroundColor(0xFFEEF4F1.toInt())
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.let { loader.shouldInterceptRequest(it.url) }
        }
        ui.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton("ঠিক আছে") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton("ঠিক আছে") { _, _ -> result?.confirm() }
                    .setNegativeButton("বাতিল") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try {
                    startActivityForResult(fileChooserParams!!.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (auth.visibility == View.VISIBLE) moveTaskToBack(true)
        else if (showingWa) show(false) else moveTaskToBack(true)
    }

    override fun onDestroy() {
        stopService(Intent(this, KeepAliveService::class.java))
        ui.destroy()
        wa.destroy()
        auth.destroy()
        super.onDestroy()
    }

    // ---------- দুই WebView-এর মাঝে বার্তা আদান-প্রদান ----------
    private fun toUi(json: String) {
        ui.evaluateJavascript("window.__cmRecv&&window.__cmRecv(${JSONObject.quote(json)})", null)
    }

    private fun toWa(json: String, kind: String, id: String) {
        val q = JSONObject.quote(json)
        wa.evaluateJavascript("(typeof window.__cmRecv==='function')?(window.__cmRecv($q),true):false") { v ->
            if (v != "true" && kind == "req") toUi("{\"kind\":\"res\",\"id\":${JSONObject.quote(id)},\"payload\":null}")
        }
    }

    private fun changed(json: String) {
        runOnUiThread { ui.evaluateJavascript("window.__cmStorageChanged&&window.__cmStorageChanged($json)", null) }
    }

    /** JavaScript থেকে ডাকা যায় এমন ফাংশন। fromUi=false হলো WhatsApp পেজ, তাই তার অনুমতি কম। */
    inner class Native(private val fromUi: Boolean) {
        @JavascriptInterface
        fun storageGet(keys: String): String {
            val list = if (keys == "null") null else JSONArray(keys).let { a -> List(a.length()) { a.getString(it) } }
            return store.get(list)
        }

        @JavascriptInterface
        fun storageSet(pairs: String) {
            val a = JSONArray(pairs)
            val ch = StringBuilder("{")
            for (i in 0 until a.length()) {
                val p = a.getJSONArray(i)
                val k = p.getString(0)
                val v = p.getString(1)
                store.put(k, v)
                if (i > 0) ch.append(',')
                val nv = if (k != "att" && v.length < 2_000_000) v else "null"
                ch.append(JSONObject.quote(k)).append(":{\"newValue\":").append(nv).append('}')
            }
            ch.append('}')
            changed(ch.toString())
        }

        @JavascriptInterface
        fun storageRemove(keys: String) {
            val a = JSONArray(keys)
            val ch = StringBuilder("{")
            for (i in 0 until a.length()) {
                val k = a.getString(i)
                store.remove(k)
                if (i > 0) ch.append(',')
                ch.append(JSONObject.quote(k)).append(":{}")
            }
            ch.append('}')
            changed(ch.toString())
        }

        @JavascriptInterface
        fun route(json: String) {
            val o = JSONObject(json)
            val to = o.optString("to")
            val kind = o.optString("kind")
            if (!fromUi && kind == "req") {
                // WhatsApp পেজ শুধু কাজ চাওয়া (getJob) আর ফল জানানো (result) পারবে
                val t = o.optJSONObject("payload")?.optString("type")
                if (t != "getJob" && t != "result") return
            }
            runOnUiThread {
                if (to == "wa") toWa(json, kind, o.optString("id")) else toUi(json)
            }
        }

        @JavascriptInterface
        fun loadUrl(url: String) {
            if (!fromUi || !url.startsWith("https://web.whatsapp.com/")) return
            runOnUiThread { wa.loadUrl(url) }
        }

        @JavascriptInterface
        fun exec(id: String, code: String, files: String) {
            if (!fromUi) return
            runOnUiThread {
                val arr = JSONArray(files)
                val sb = StringBuilder()
                if (arr.length() > 0) {
                    sb.append(shimSrc).append("\n;")
                    for (i in 0 until arr.length()) {
                        val name = arr.getString(i)
                        if (name !in allowedFiles) continue
                        val src = asset(name)
                        if (name == "content.js") sb.append("if(!window.__cm){(function(){\n").append(src).append("\n})();}\n")
                        else sb.append(src).append("\n;")
                    }
                    sb.append("0;")
                } else {
                    sb.append(code)
                }
                wa.evaluateJavascript(sb.toString()) { v ->
                    toUi("{\"kind\":\"res\",\"id\":${JSONObject.quote(id)},\"payload\":${v ?: "null"}}")
                }
            }
        }
    }
}
