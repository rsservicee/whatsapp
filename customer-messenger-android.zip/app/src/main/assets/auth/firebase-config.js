// ===== এখানে নিজের তথ্য বসান =====
window.CM_CONFIG = {
  apiKey: "AIzaSyAdSEaa2C3axEPy4oaF3fdsozOBNGcFoJg",
  projectId: "whatsaapbot-cf5b1",
  emailDomain: "customermessenger.app",   // বদলাবেন না (অ্যাডমিন সাইটেও একই থাকতে হবে)
  waNumber: "8801581619706",              // আপনার WhatsApp নম্বর, দেশের কোডসহ, + ছাড়া
  waText: "আসসালামু আলাইকুম, কাস্টমার মেসেজার অ্যাপের ইউজারনেম ও পাসওয়ার্ড কিনতে চাই।",
  recheckMinutes: 10                      // অ্যাপ চলাকালীন কত মিনিট পরপর মেয়াদ যাচাই হবে
};
