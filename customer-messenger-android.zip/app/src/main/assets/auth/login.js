(function () {
  var C = window.CM_CONFIG || {};
  var N = window.__authNative;
  var LS = window.localStorage;
  var DAY = 86400000;
  var $ = function (id) { return document.getElementById(id); };

  var AUTH = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + C.apiKey;
  var REFRESH = 'https://securetoken.googleapis.com/v1/token?key=' + C.apiKey;
  var DOC = 'https://firestore.googleapis.com/v1/projects/' + C.projectId + '/databases/(default)/documents/users/';

  function configured() {
    return C.apiKey && C.apiKey.indexOf('YOUR_') !== 0 && C.projectId && C.projectId.indexOf('YOUR_') !== 0;
  }
  function toEmail(u) {
    return String(u).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '') + '@' + C.emailDomain;
  }
  function say(text, isErr) {
    var m = $('msg');
    if (!text) { m.hidden = true; return; }
    m.textContent = text;
    m.className = 'msg' + (isErr ? ' err' : '');
    m.hidden = false;
  }
  function busy(b) {
    $('go').disabled = b;
    $('go').textContent = b ? 'অপেক্ষা করুন...' : 'লগইন';
  }

  // ---- নেটওয়ার্ক ----
  function parse(r) {
    return r.json().catch(function () { return {}; }).then(function (j) {
      if (!r.ok) {
        var e = new Error((j.error && j.error.message) || ('HTTP ' + r.status));
        e.status = r.status;
        throw e;
      }
      return j;
    });
  }
  function netErr() { throw new Error('NET'); }
  function postJson(url, body) {
    return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(parse, netErr);
  }
  function refreshToken(rt) {
    return fetch(REFRESH, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(rt)
    }).then(parse, netErr);
  }

  // ---- সেশন ও ক্যাশ ----
  function getJ(k) { try { return JSON.parse(LS.getItem(k)); } catch (e) { return null; } }
  function setJ(k, v) { LS.setItem(k, JSON.stringify(v)); }
  function bumpClock() {
    var m = +LS.getItem('cm_max') || 0, n = Date.now();
    if (n > m) LS.setItem('cm_max', String(n));
  }
  function clockBad() {
    var m = +LS.getItem('cm_max') || 0;
    return Date.now() < m - 10 * 60 * 1000;
  }
  function clearSession() { LS.removeItem('cm_sess'); LS.removeItem('cm_cache'); }

  // ---- অ্যাক্সেস যাচাই ----
  function getAccess(uid, idToken) {
    return fetch(DOC + uid, { headers: { Authorization: 'Bearer ' + idToken } }).then(function (r) {
      if (r.status === 404 || r.status === 403) return { ok: false, reason: 'nodoc' };
      return parse(r).then(function (d) {
        var f = d.fields || {};
        var active = f.active ? f.active.booleanValue === true : false;
        var exp = f.expiresAt ? Number(f.expiresAt.integerValue || f.expiresAt.doubleValue || 0) : 0;
        if (!active) return { ok: false, reason: 'inactive' };
        if (exp <= Date.now()) return { ok: false, reason: 'expired' };
        return { ok: true, expiresAt: exp };
      });
    }, netErr);
  }

  var REASONS = {
    nodoc: 'এই অ্যাকাউন্টটি চালু করা হয়নি। WhatsApp-এ যোগাযোগ করুন।',
    inactive: 'আপনার অ্যাকাউন্ট বন্ধ আছে। WhatsApp-এ যোগাযোগ করুন।',
    expired: 'আপনার মেয়াদ শেষ হয়েছে। নবায়ন করতে WhatsApp-এ যোগাযোগ করুন।'
  };
  function errText(e) {
    var m = String(e && e.message || '');
    if (m === 'NET') return 'ইন্টারনেট সংযোগ নেই।';
    if (/INVALID_LOGIN_CREDENTIALS|EMAIL_NOT_FOUND|INVALID_PASSWORD/.test(m)) return 'ইউজারনেম বা পাসওয়ার্ড ভুল।';
    if (/TOO_MANY_ATTEMPTS/.test(m)) return 'অনেকবার ভুল হয়েছে, কিছুক্ষণ পরে চেষ্টা করুন।';
    if (/USER_DISABLED/.test(m)) return 'আপনার অ্যাকাউন্ট বন্ধ করা আছে।';
    return 'লগইন করা যায়নি (' + m + ')';
  }

  function unlock(expiresAt) {
    var s = getJ('cm_sess') || {};
    setJ('cm_cache', { uid: s.uid, expiresAt: expiresAt, checkedAt: Date.now() });
    bumpClock();
    say('');
    if (N) N.ok();
  }
  function lock(text) {
    if (N) N.lock();
    say(text, true);
    busy(false);
  }

  // সেভ করা সেশন দিয়ে যাচাই (অ্যাপ খোলার সময় ও নির্দিষ্ট সময় পরপর)
  function verify() {
    var s = getJ('cm_sess');
    if (!s || !s.refresh) return Promise.resolve(false);
    if (clockBad()) { lock('ফোনের তারিখ/সময় ঠিক করুন।'); return Promise.resolve(false); }
    return refreshToken(s.refresh).then(function (t) {
      s.refresh = t.refresh_token || s.refresh;
      setJ('cm_sess', s);
      return getAccess(s.uid, t.id_token);
    }).then(function (res) {
      if (res.ok) { unlock(res.expiresAt); return true; }
      clearSession();
      lock(REASONS[res.reason] || 'আবার লগইন করুন।');
      return false;
    }).catch(function (e) {
      if (e && (e.message === 'NET' || e.status >= 500)) {
        // অফলাইনে সর্বোচ্চ ৪৮ ঘণ্টা আগের সফল যাচাইয়ের ভিত্তিতে চলবে
        var c = getJ('cm_cache');
        if (c && c.uid === s.uid && Date.now() < c.expiresAt && Date.now() - c.checkedAt < 2 * DAY && !clockBad()) {
          bumpClock();
          if (N) N.ok();
          return true;
        }
        lock('যাচাই করতে ইন্টারনেট দরকার।');
        return false;
      }
      clearSession();
      lock('আবার লগইন করুন।');
      return false;
    });
  }

  // ---- লগইন ফর্ম ----
  $('f').onsubmit = function (ev) {
    ev.preventDefault();
    if (!configured()) { say('অ্যাপের Firebase কনফিগ বসানো হয়নি।', true); return; }
    var u = $('u').value, p = $('p').value;
    if (!u.trim() || !p) { say('ইউজারনেম ও পাসওয়ার্ড দিন।', true); return; }
    if (clockBad()) { say('ফোনের তারিখ/সময় ঠিক করুন।', true); return; }
    busy(true); say('');
    var sess;
    postJson(AUTH, { email: toEmail(u), password: p, returnSecureToken: true }).then(function (r) {
      sess = { uid: r.localId, refresh: r.refreshToken, user: u.trim() };
      return getAccess(r.localId, r.idToken);
    }).then(function (res) {
      if (!res.ok) { say(REASONS[res.reason], true); busy(false); return; }
      setJ('cm_sess', sess);
      $('p').value = '';
      busy(false);
      unlock(res.expiresAt);
    }).catch(function (e) {
      say(errText(e), true);
      busy(false);
    });
  };

  // ---- WhatsApp বাটন ----
  $('wa').onclick = function () {
    var num = String(C.waNumber || '').replace(/[^0-9]/g, '');
    var url = 'https://wa.me/' + num + '?text=' + encodeURIComponent(C.waText || '');
    if (N && N.openUrl) N.openUrl(url); else window.open(url, '_blank');
  };

  // ---- শুরু ----
  if (!configured()) {
    say('অ্যাপের Firebase কনফিগ বসানো হয়নি।', true);
  } else if (getJ('cm_sess')) {
    say('যাচাই করা হচ্ছে...');
    verify().then(function (ok) { if (ok) say(''); });
  }
  var mins = Math.max(1, Number(C.recheckMinutes) || 10);
  setInterval(function () { if (configured()) verify(); }, mins * 60000);
})();
