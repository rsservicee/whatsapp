// chrome.* API-এর অনুকরণ: এক্সটেনশনের কোড অ্যাপের ভেতরে হুবহু চালানোর জন্য।
// দুই জায়গায় চলে: "ui" (popup.html + background.js) ও "wa" (WhatsApp Web পেজ, যেখানে content.js চলে)
(() => {
  if (window.__cmShim) return;
  window.__cmShim = true;
  const N = window.__cmNative;
  const IS_UI = location.host === 'appassets.androidplatform.net';
  const ME = IS_UI ? 'ui' : 'wa';
  const L = { msg: [], storage: [], alarm: [] };
  const pending = new Map();
  let seq = 0;
  const newId = () => ME + (++seq) + Math.random().toString(36).slice(2);
  const later = (cb, v) => { if (typeof cb === 'function') { setTimeout(() => cb(v), 0); return undefined; } return Promise.resolve(v); };

  // অন্য পাশে অনুরোধ পাঠিয়ে উত্তরের অপেক্ষা। সময় শেষ হলে undefined
  const request = (send, ms) => new Promise(res => {
    const id = newId();
    const t = setTimeout(() => { pending.delete(id); res(undefined); }, ms);
    pending.set(id, { res, t });
    send(id);
  });

  // নিজের পাশের onMessage শ্রোতাদের কাছে বার্তা পৌঁছে দেওয়া
  const dispatch = m => new Promise(resolve => {
    let done = false, wait = false;
    const respond = r => { if (!done) { done = true; resolve(r); } };
    for (const fn of L.msg) {
      try { if (fn(m, {}, respond) === true) wait = true; } catch (e) {}
    }
    if (!wait && !done) { done = true; resolve(undefined); }
  });

  window.__cmRecv = async s => {
    let e;
    try { e = JSON.parse(s); } catch (x) { return; }
    if (e.kind === 'res') {
      const p = pending.get(e.id);
      if (p) { clearTimeout(p.t); pending.delete(e.id); p.res(e.payload); }
      return;
    }
    const r = await dispatch(e.payload);
    N.route(JSON.stringify({ to: e.from, from: ME, id: e.id, kind: 'res', payload: r === undefined ? null : r }));
  };

  window.__cmStorageChanged = ch => L.storage.forEach(f => { try { f(ch, 'local'); } catch (e) {} });

  const keyList = k => k == null ? null : typeof k === 'string' ? [k] : Array.isArray(k) ? k : Object.keys(k);
  const local = {
    get(keys, cb) {
      let out = {};
      try { out = JSON.parse(N.storageGet(JSON.stringify(keyList(keys)))); } catch (e) {}
      if (keys && typeof keys === 'object' && !Array.isArray(keys)) for (const k of Object.keys(keys)) if (!(k in out)) out[k] = keys[k];
      return later(cb, out);
    },
    set(obj, cb) {
      const pairs = [];
      for (const [k, v] of Object.entries(obj || {})) if (v !== undefined) pairs.push([k, JSON.stringify(v)]);
      if (pairs.length) N.storageSet(JSON.stringify(pairs));
      return later(cb);
    },
    remove(keys, cb) {
      N.storageRemove(JSON.stringify(keyList(keys) || []));
      return later(cb);
    }
  };

  const sendRuntime = (msg, cb) => {
    const p = IS_UI
      ? dispatch(msg)
      : request(id => N.route(JSON.stringify({ to: 'ui', from: 'wa', id, kind: 'req', payload: msg })), 30000);
    if (typeof cb === 'function') { p.then(cb); return undefined; }
    return p;
  };

  const api = {
    runtime: { sendMessage: sendRuntime, onMessage: { addListener: f => { L.msg.push(f); } } },
    storage: { local, onChanged: { addListener: f => { L.storage.push(f); } } }
  };

  if (IS_UI) {
    const timers = {};
    const fireAlarm = name => L.alarm.forEach(f => { try { f({ name }); } catch (e) {} });
    Object.assign(api, {
      tabs: {
        query: (q, cb) => later(cb, [{ id: 1, url: 'https://web.whatsapp.com/' }]),
        sendMessage: (id, msg, cb) => {
          const p = request(rid => N.route(JSON.stringify({ to: 'wa', from: 'ui', id: rid, kind: 'req', payload: msg })), 90000);
          if (typeof cb === 'function') { p.then(cb); return undefined; }
          return p;
        },
        update: (id, props, cb) => { if (props && props.url) N.loadUrl(props.url); return later(cb, { id: 1 }); },
        create: (props, cb) => { if (props && props.url) N.loadUrl(props.url); return later(cb, { id: 1 }); }
      },
      scripting: {
        executeScript: o => request(
          rid => N.exec(rid, o.func ? '(' + o.func.toString() + ')()' : '', JSON.stringify(o.files || [])), 60000
        ).then(r => [{ result: r }])
      },
      alarms: {
        create: (name, info) => {
          clearTimeout(timers[name]);
          const d = Math.max(0, ((info && info.when) || Date.now()) - Date.now());
          timers[name] = setTimeout(() => fireAlarm(name), d);
        },
        clear: name => { clearTimeout(timers[name]); return Promise.resolve(true); },
        onAlarm: { addListener: f => { L.alarm.push(f); } }
      },
      action: { onClicked: { addListener() {} } },
      windows: { create() {} }
    });
    // Chrome-এর alarms যেমন নির্দিষ্ট সময় পরপর জাগায়, তেমনি: অ্যাপ নতুন করে খুললে বা কিছু আটকে থাকলে পরের মেসেজ ধরিয়ে দেয়
    setTimeout(() => fireAlarm('tick'), 2500);
    setInterval(() => fireAlarm('tick'), 10000);
  }

  try { window.chrome = Object.assign(window.chrome || {}, api); } catch (e) { /* ignore */ }
})();
