window.__cm = true;
const sleep = ms => new Promise(r => setTimeout(r, ms));
chrome.runtime.onMessage.addListener((m, s, reply) => {
  if (m.type === 'status') reply({ ready: !!document.querySelector('#pane-side, footer') });
  if (m.type === 'extract') { extractNumbers().then(reply); return true; }
  if (m.type === 'deep') { deepExtract(); reply({}); }
  if (m.type === 'labels' || m.type === 'labelNumbers' || m.type === 'allNumbers') {
    const id = Math.random().toString(36).slice(2);
    const onMsg = ev => {
      const d = ev.data;
      if (ev.source !== window || !d || d.cm !== 'res' || d.id !== id) return;
      window.removeEventListener('message', onMsg); clearTimeout(timer); reply(d);
    };
    const timer = setTimeout(() => { window.removeEventListener('message', onMsg); reply({ ok: false, err: 'সময় শেষ, আবার চেষ্টা করুন' }); }, 60000);
    window.addEventListener('message', onMsg);
    window.postMessage({ cm: 'req', id, op: m.type, arg: m.type === 'allNumbers' ? m.prefix : m.labelId }, '*');
    return true;
  }
});

// প্রতিটি চ্যাট খুলে মেসেজের ভেতর থেকে নম্বর নেওয়া (সেভ করা কন্টাক্টের জন্যও কাজ করে, গ্রুপ বাদ)
function numberFromOpenChat() {
  for (const e of document.querySelectorAll('#main [data-id]')) {
    const m = /^(?:true|false)_(\d{10,15})@c\.us_/.exec(e.getAttribute('data-id') || '');
    if (m) return m[1];
  }
  return null;
}

async function addGot(n) {
  const { got } = await chrome.storage.local.get('got');
  const lines = (got || '').split('\n').filter(Boolean);
  if (lines.some(l => l.split(',')[0].replace(/\D/g, '') === n)) return false;
  lines.push(n);
  await chrome.storage.local.set({ got: lines.join('\n') });
  return true;
}

async function deepExtract() {
  const pane = document.querySelector('#pane-side');
  const note = t => chrome.storage.local.set({ extnote: t });
  if (!pane) return note('WhatsApp Web-এ লগইন করুন');
  const startedAt = Date.now();
  const stopped = async () => { const { extstop } = await chrome.storage.local.get('extstop'); return extstop > startedAt; };
  const seen = new Set();
  let scanned = 0, found = 0, noMain = 0, lid = 0;
  pane.scrollTop = 0; await sleep(800);
  outer: for (let round = 0; round < 60; round++) {
    for (const t of [...pane.querySelectorAll('span[title]')]) {
      const key = (t.getAttribute('title') || '').trim();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      if (await stopped()) { note(`বন্ধ করা হয়েছে। ${scanned}টি চ্যাট দেখা হয়েছে, ${found}টি নতুন নম্বর পাওয়া গেছে`); return; }
      for (const type of ['mousedown', 'mouseup', 'click']) t.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true }));
      await sleep(900 + Math.random() * 500);
      scanned++;
      const num = numberFromOpenChat();
      if (!document.querySelector('#main')) noMain++;
      else if (!num && [...document.querySelectorAll('#main [data-id]')].some(e => /@lid_/.test(e.getAttribute('data-id') || ''))) lid++;
      if (num && await addGot(num)) found++;
      note(`চ্যাট দেখা হচ্ছে… ${scanned}টি দেখা হলো, ${found}টি নম্বর পাওয়া গেছে`);
      if (scanned >= 150) break outer;
    }
    const prev = pane.scrollTop;
    pane.scrollTop += pane.clientHeight * 0.8;
    await sleep(900);
    if (pane.scrollTop === prev) break;
  }
  note(`শেষ। ${scanned}টি চ্যাট দেখা হয়েছে, ${found}টি নতুন নম্বর পাওয়া গেছে` + (scanned === 0 ? ' — চ্যাট লিস্টে কিছু খুঁজে পাওয়া যায়নি' : '') + (noMain ? ` · চ্যাট খোলেনি: ${noMain}` : '') + (lid ? ` · নম্বর লুকানো: ${lid}` : ''));
}

// নিজের চ্যাট লিস্টে যাদের নাম হিসেবে নম্বর দেখা যায় (সেভ না করা কন্টাক্ট), তাদের নম্বর সংগ্রহ
async function extractNumbers() {
  const pane = document.querySelector('#pane-side');
  if (!pane) return { err: 'WhatsApp Web-এ লগইন করুন' };
  const found = new Set();
  const scan = () => pane.querySelectorAll('span[title]').forEach(el => {
    const t = (el.getAttribute('title') || '').trim();
    if (/^\+?[\d\s\-()]{9,}$/.test(t)) {
      const d = t.replace(/\D/g, '');
      if (d.length >= 10 && d.length <= 15) found.add(d);
    }
  });
  pane.scrollTop = 0; await sleep(500);
  for (let i = 0; i < 25; i++) {
    scan();
    const prev = pane.scrollTop;
    pane.scrollTop += pane.clientHeight * 0.8;
    await sleep(600);
    if (pane.scrollTop === prev) break;
  }
  scan();
  pane.scrollTop = 0;
  return { nums: [...found] };
}

const report = (ok, why) => chrome.runtime.sendMessage({ type: 'result', ok, why });
// "send" নামের যেকোনো আইকন/বাটন (WhatsApp-এর নতুন ও পুরোনো ডিজাইন দুটোই ধরে)
const SEND_ANY = '[data-icon*="send"], button[aria-label="Send"], [role="button"][aria-label="Send"]';
const editables = () => [...document.querySelectorAll('[contenteditable="true"]')].filter(e => !e.closest('#side, #pane-side'));
const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);

async function typeInto(el, text) {
  el.focus();
  text.split('\n').forEach((ln, i) => {
    if (i) document.execCommand('insertLineBreak');
    if (ln) document.execCommand('insertText', false, ln);
  });
  await sleep(500);
  if (!el.innerText.trim()) { // বিকল্প: পেস্ট ইভেন্ট
    const dt = new DataTransfer();
    dt.setData('text/plain', text);
    el.focus();
    el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    await sleep(500);
  }
}

async function waitFor(fn, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { const v = fn(); if (v) return v; await sleep(400); }
  return null;
}

function b64ToFile(a) {
  const bin = atob(a.data), u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return new File([u], a.name, { type: a.type });
}

// আসল মাউস ক্লিকের মতো পুরো ইভেন্ট-ক্রম পাঠায় (শুধু .click() অনেক সময় কাজ করে না)
// pointerType: 'mouse' না থাকলে WhatsApp অনেক সময় ক্লিক উপেক্ষা করে
function press(el) {
  const r = el.getBoundingClientRect();
  const o = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
  for (const t of ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
    const isPtr = t.startsWith('pointer');
    const init = { ...o, buttons: t.endsWith('down') ? 1 : 0 };
    el.dispatchEvent(new (isPtr ? PointerEvent : MouseEvent)(t, isPtr ? { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true } : init));
  }
}

function pressEnter(el) {
  el.focus();
  for (const t of ['keydown', 'keypress', 'keyup'])
    el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true }));
}

async function sendAttachment(job) {
  const { att } = await chrome.storage.local.get('att');
  if (!att) return report(false, 'ফাইল সেভ হয়নি');
  const composer = await waitFor(() => document.querySelector('footer div[contenteditable="true"]'), 45000);
  if (!composer) return report(false, 'চ্যাট বক্স পাওয়া যায়নি');
  await sleep(1000 + Math.random() * 1000);

  // পেস্টের আগের অবস্থা মনে রাখি, যাতে প্রিভিউয়ের নতুন বক্স/বাটন আলাদা করে চেনা যায়
  const editBefore = new Set(editables());
  const sendBefore = new Set(document.querySelectorAll(SEND_ANY));
  const btnBefore = new Set(document.querySelectorAll('button, [role="button"]'));
  const newSend = () => [...document.querySelectorAll(SEND_ANY)].filter(e => !sendBefore.has(e) && visible(e));
  const newEdit = () => editables().filter(e => !editBefore.has(e) && visible(e));
  const previewUp = () => newSend().length > 0 || newEdit().length > 0;

  const dt = new DataTransfer();
  dt.items.add(b64ToFile(att));
  composer.focus();
  composer.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  let up = await waitFor(previewUp, 12000);

  if (!up) { // বিকল্প: অ্যাটাচ মেনুর file input
    const plus = document.querySelector('footer span[data-icon="plus"], footer span[data-icon="attach-menu-plus"], footer span[data-icon="clip"]');
    if (plus) (plus.closest('button, [role="button"]') || plus).click();
    await sleep(900);
    const media = /^(image|video)\//.test(att.type);
    const inputs = [...document.querySelectorAll('input[type="file"]')];
    const inp = inputs.find(i => media ? /image|video/.test(i.accept) : !/image|video/.test(i.accept)) || inputs[0];
    if (inp) { inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true })); }
    up = await waitFor(previewUp, 15000);
  }
  if (!up) return report(false, 'ফাইলের প্রিভিউ খোলেনি');
  await sleep(1500); // ছবি লোড হওয়ার সময়

  let cap = null;
  if (job.text) {
    cap = newEdit().pop() || editables().filter(visible).pop();
    if (!cap) return report(false, 'ক্যাপশন বক্স পাওয়া যায়নি');
    await typeInto(cap, job.text);
  }

  await sleep(1200 + Math.random() * 800); // ক্যাপশনে লিংক থাকলে WhatsApp প্রিভিউ বানাতে সময় নেয়

  const iconBtn = () => { const e = newSend().pop(); return e && (e.closest('button, [role="button"]') || e); };
  // নিচের ডানদিকের সবচেয়ে ডানের নতুন বাটনই সাধারণত Send
  const cornerBtn = () => [...document.querySelectorAll('button, [role="button"]')]
    .filter(b => !btnBefore.has(b) && visible(b) && b.getBoundingClientRect().top > innerHeight * 0.55)
    .sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right)[0];

  // প্রিভিউ সত্যিই বন্ধ হয়েছে কিনা। বন্ধ দেখলে ০.৮ সেকেন্ড পরে আবার দেখে (ক্ষণিক রি-রেন্ডারে ভুল ধরা এড়াতে)
  const gone = () => !previewUp();
  const confirmGone = async ms => {
    const end = Date.now() + ms;
    do {
      if (gone()) { await sleep(800); if (gone()) return true; }
      await sleep(300);
    } while (Date.now() < end);
    return false;
  };

  // একটা কাজ না করলে পরেরটা। আগে আসল মাউস-ক্লিক, তারপর Enter, শেষে সাধারণ ক্লিক
  const steps = [
    () => { const e = iconBtn(); if (e) press(e); },
    () => { const e = cornerBtn(); if (e) press(e); },
    () => { if (cap) pressEnter(cap); },
    () => { const e = iconBtn(); if (e) e.click(); },
    () => { const e = cornerBtn(); if (e) e.click(); },
  ];
  let sent = false;
  for (const step of steps) {
    if (await confirmGone(0)) { sent = true; break; }
    step();
    if (await confirmGone(5000)) { sent = true; break; }
  }
  if (!sent) return report(false, 'Send চাপা হয়নি (প্রিভিউ বন্ধ হয়নি)');
  // ফাইল আপলোড শেষ হওয়ার আগে পেজ বদলালে মেসেজ আটকে যায়, তাই ফাইলের আকার অনুযায়ী অপেক্ষা
  const mb = (att.data.length * 0.75) / (1024 * 1024);
  await sleep(3000 + mb * 1500);
  report(true);
}

(async () => {
  const job = await chrome.runtime.sendMessage({ type: 'getJob' });
  if (!job) return;
  if (job.hasAtt) return sendAttachment(job);

  const deadline = Date.now() + 45000;
  let btn = null;
  while (Date.now() < deadline) {
    const icon = document.querySelector('footer span[data-icon="send"], footer span[data-icon="wds-ic-send-filled"]');
    btn = (icon && icon.closest('button')) || document.querySelector('footer button[aria-label="Send"]');
    if (btn) break;
    await sleep(500);
  }
  if (!btn) return chrome.runtime.sendMessage({ type: 'result', ok: false, why: 'Send বাটন পাওয়া যায়নি বা নম্বর ভুল' });

  await sleep(800 + Math.random() * 1200);
  btn.click();
  await sleep(2500);
  chrome.runtime.sendMessage({ type: 'result', ok: true });
})();
