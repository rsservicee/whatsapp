const $ = id => document.getElementById(id);

// WhatsApp ট্যাব আগে থেকে খোলা থাকলেও এক্সটেনশন নিজেই কোড বসিয়ে নেয়, F5 লাগে না
async function ensureInjected(tabId, wantMain) {
  const [{ result: hasContent }] = await chrome.scripting.executeScript({ target: { tabId }, func: () => !!window.__cm });
  if (!hasContent) await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  if (wantMain) {
    const [{ result: hasBridge }] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: () => !!window.__cmBridge });
    if (!hasBridge) await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['wppconnect-wa.js', 'bridge-main.js'] });
  }
}

function normalize(raw) {
  let d = raw.replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (d.length === 11 && d.startsWith('01')) d = '88' + d;
  else if (d.length === 10 && d.startsWith('1')) d = '880' + d;
  return d.length >= 10 && d.length <= 15 ? d : null;
}

function parse() {
  const seen = new Set(), items = [];
  for (const line of $('nums').value.split('\n')) {
    const [n, ...rest] = line.split(',');
    const phone = normalize(n || '');
    if (phone && !seen.has(phone)) { seen.add(phone); items.push({ phone, name: rest.join(',').trim() }); }
  }
  return items;
}

function saveForm() {
  chrome.storage.local.set({ form: { nums: $('nums').value, msg: $('msg').value, min: $('min').value, max: $('max').value, limit: $('limit').value } });
}

async function load() {
  const { form } = await chrome.storage.local.get('form');
  if (form) for (const k of Object.keys(form)) $(k === 'nums' ? 'nums' : k).value = form[k];
  $('cnt').textContent = `(${parse().length})`;
  render();
}

let cur = null; // সর্বশেষ অবস্থা, কাউন্টডাউনের জন্য

async function render() {
  const { st, d } = await chrome.storage.local.get(['st', 'd']);
  cur = st || null;
  const live = $('live');
  if (!st || !st.queue.length) { live.style.display = 'none'; $('status').textContent = ''; return; }
  live.style.display = 'flex';
  live.classList.toggle('on', !!st.running);
  const total = st.queue.length;
  const sent = st.queue.filter(i => i.status === 'sent').length;
  const failed = st.queue.filter(i => i.status === 'failed');
  const left = total - sent - failed.length;
  $('lvstate').textContent = st.running ? 'চলছে' : 'থেমে আছে';
  $('pfill').style.width = ((sent + failed.length) / total * 100) + '%';
  let c = `পাঠানো ${sent} · ব্যর্থ ${failed.length} · বাকি ${left}`;
  if (d) c += ` · আজ মোট ${d.count}`;
  if (st.running && left > 0 && st.min) c += `\nআনুমানিক ${Math.max(1, Math.round(left * (st.min + st.max) / 2 / 60))} মিনিট বাকি`;
  $('lvcounts').textContent = c;
  $('lvcounts').style.whiteSpace = 'pre-line';
  let t = '';
  if (st.hasAtt) t += 'ফাইলসহ পাঠানো হচ্ছে\n';
  if (st.note) t += st.note + '\n';
  if (failed.length) t += 'ব্যর্থ নম্বর: ' + failed.map(i => i.phone + (i.why ? ' (' + i.why + ')' : '')).join(', ');
  $('status').textContent = t.trim();
  tickUI();
}

function tickUI() {
  const st = cur;
  if (!st || !st.queue.length) return;
  const C = 2 * Math.PI * 34;
  let num = '–', lbl = 'থেমে আছে', frac = 0;
  if (st.running) {
    const it = st.queue[st.idx];
    const rem = (st.nextAt || 0) - Date.now();
    if ((it && it.status === 'sending') || st.nextAt >= 9e15) { num = '…'; lbl = 'এখন পাঠানো হচ্ছে'; frac = 1; }
    else if (rem > 0) { num = Math.ceil(rem / 1000); lbl = 'সেকেন্ড পরে পরের মেসেজ'; frac = st.delay ? Math.min(1, rem / st.delay) : 0; }
    else { num = '…'; lbl = 'শুরু হচ্ছে'; }
  } else if (st.idx >= st.queue.length) { num = '✓'; lbl = 'সব শেষ'; }
  $('cdnum').textContent = num;
  $('cdlbl').textContent = lbl;
  const ring = $('ring');
  ring.style.strokeDasharray = C;
  ring.style.strokeDashoffset = C * (1 - frac);
}
setInterval(tickUI, 500);

for (const id of ['nums', 'msg', 'min', 'max', 'limit'])
  $(id).addEventListener('input', () => { saveForm(); $('cnt').textContent = `(${parse().length})`; });

$('start').onclick = async () => {
  const { att } = await chrome.storage.local.get('att');
  const items = parse(), text = $('msg').value.trim();
  const min = Math.max(10, +$('min').value || 20);
  const max = Math.max(min, +$('max').value || 60);
  const limit = Math.max(1, +$('limit').value || 50);
  if (!items.length) return alert('কোনো সঠিক নম্বর পাওয়া যায়নি');
  if (!text && !att) return alert('মেসেজ লিখুন বা ফাইল দিন');
  chrome.runtime.sendMessage({ type: 'start', items, text, min, max, limit, hasAtt: !!att });
};
$('stop').onclick = () => chrome.runtime.sendMessage({ type: 'stop' });

async function showAtt() {
  const { att } = await chrome.storage.local.get('att');
  $('fname').textContent = att ? 'নির্বাচিত: ' + att.name : '';
  $('rm').style.display = att ? 'inline' : 'none';
}

$('file').addEventListener('change', async () => {
  const f = $('file').files[0];
  if (!f) return;
  if (f.size > 16 * 1024 * 1024) { $('file').value = ''; return alert('ফাইল ১৬MB-এর বেশি'); }
  const data = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result.split(',')[1]); fr.readAsDataURL(f); });
  await chrome.storage.local.set({ att: { name: f.name, type: f.type || 'application/octet-stream', data } });
  showAtt();
});

$('rm').onclick = async e => {
  e.preventDefault();
  await chrome.storage.local.remove('att');
  $('file').value = '';
  showAtt();
};

$('ext').onclick = async () => {
  $('extnote').textContent = 'নম্বর আনা হচ্ছে…';
  try {
    const cc = $('cc').value.replace(/\D/g, '');
    const r = await callWA({ type: 'allNumbers', prefix: cc });
    const have = new Set($('got').value.split('\n').map(x => x.split(',')[0].replace(/\D/g, '')));
    const add = r.items.filter(i => !have.has(i.phone));
    if (add.length) $('got').value = ($('got').value.trim() ? $('got').value.trim() + '\n' : '') + add.map(i => i.phone + (i.name ? ',' + i.name : '')).join('\n');
    gotChanged();
    const dup = r.items.length - add.length;
    $('extnote').textContent = `${r.items.length}টি নম্বর পাওয়া গেছে${cc ? ` (+${cc})` : ''}` + (dup ? `, আগে থেকেই বক্সে ছিল ${dup}টি` : '') + (r.other ? `, অন্য দেশের ${r.other}টি বাদ` : '') + (r.hidden ? `, ${r.hidden}টির নম্বর পাওয়া যায়নি` : '') + '।';
  } catch (err) { $('extnote').textContent = err.message; }
};

async function checkWA() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  let s = 'none';
  if (tabs.length) {
    s = 'wait';
    for (const t of tabs) {
      try { await ensureInjected(t.id); const r = await chrome.tabs.sendMessage(t.id, { type: 'status' }); if (r && r.ready) { s = 'ready'; break; } } catch (e) {}
    }
  }
  $('wa').className = 'wa ' + s;
  $('watext').textContent = { ready: 'WhatsApp Web-এর সাথে সংযুক্ত', wait: 'WhatsApp Web লগইন করুন বা ট্যাব রিলোড করুন', none: 'WhatsApp Web খোলা নেই' }[s];
}

chrome.storage.onChanged.addListener(render);
load();
showAtt();
checkWA();
setInterval(checkWA, 3000);

function updGotCnt() {
  const n = $('got').value.split('\n').filter(x => x.replace(/\D/g, '').length >= 10).length;
  $('gotcnt').textContent = n ? `(${n})` : '';
}
function gotChanged() { updGotCnt(); chrome.storage.local.set({ got: $('got').value }); }
$('got').addEventListener('input', gotChanged);

chrome.storage.onChanged.addListener(ch => {
  if (ch.got && ch.got.newValue !== $('got').value) { $('got').value = ch.got.newValue || ''; updGotCnt(); }
  if (ch.extnote) $('extnote').textContent = ch.extnote.newValue;
});


async function callWA(msg) {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (!tabs.length) throw new Error('আগে WhatsApp Web খুলুন');
  await ensureInjected(tabs[0].id, true);
  const r = await chrome.tabs.sendMessage(tabs[0].id, msg);
  if (!r || !r.ok) throw new Error((r && r.err) || 'উত্তর পাওয়া যায়নি');
  return r;
}

$('lblload').onclick = async e => {
  e.preventDefault();
  $('extnote').textContent = 'লেবেল লোড হচ্ছে…';
  try {
    const r = await callWA({ type: 'labels' });
    const sel = $('lbl');
    sel.textContent = '';
    if (!r.labels.length) {
      sel.disabled = true; $('lblget').disabled = true;
      sel.append(new Option('কোনো লেবেল নেই', ''));
      return ($('extnote').textContent = 'কোনো লেবেল পাওয়া যায়নি। লেবেল শুধু WhatsApp Business-এ থাকে।');
    }
    for (const l of r.labels) sel.append(new Option(`${l.name} (${l.count})`, l.id));
    sel.disabled = false; $('lblget').disabled = false;
    $('extnote').textContent = `${r.labels.length}টি লেবেল পাওয়া গেছে। একটা বেছে "নম্বর আনুন" চাপুন।`;
  } catch (err) { $('extnote').textContent = err.message; }
};

$('lblget').onclick = async () => {
  const id = $('lbl').value;
  if (!id) return;
  $('extnote').textContent = 'নম্বর আনা হচ্ছে…';
  try {
    const r = await callWA({ type: 'labelNumbers', labelId: id });
    const have = new Set($('got').value.split('\n').map(x => x.split(',')[0].replace(/\D/g, '')));
    const add = r.items.filter(i => !have.has(i.phone));
    if (add.length) $('got').value = ($('got').value.trim() ? $('got').value.trim() + '\n' : '') + add.map(i => i.phone + (i.name ? ',' + i.name : '')).join('\n');
    gotChanged();
    $('extnote').textContent = `লেবেলে ${r.items.length}টি নম্বর পাওয়া গেছে, বক্সে যোগ হলো ${add.length}টি` + (r.hidden ? `, ${r.hidden}টির নম্বর পাওয়া যায়নি` : '') + '।';
  } catch (err) { $('extnote').textContent = err.message; }
};

function showPage(p) {
  for (const id of ['p1', 'p2']) $(id).style.display = id === p ? 'block' : 'none';
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.p === p));
  chrome.storage.local.set({ tab: p });
}
document.querySelectorAll('.tab').forEach(t => t.onclick = () => showPage(t.dataset.p));

$('move').onclick = () => {
  const have = new Set(parse().map(i => i.phone));
  const add = $('got').value.split('\n').filter(l => { const p = normalize(l.split(',')[0]); return p && !have.has(p); });
  if (!add.length) return ($('extnote').textContent = 'নতুন কোনো নম্বর নেই');
  $('nums').value = ($('nums').value.trim() ? $('nums').value.trim() + '\n' : '') + add.join('\n');
  saveForm(); $('cnt').textContent = `(${parse().length})`;
  showPage('p2');
};

chrome.storage.local.get(['got', 'tab']).then(({ got, tab }) => {
  if (got) { $('got').value = got; gotChanged(); }
  showPage(tab || 'p1');
});

// নতুন শুরু: সব মুছে প্রথম অবস্থায় ফিরে যায় (দৈনিক সীমার হিসাব থাকে, যাতে দিনের লিমিট ফাঁকি না যায়)
$('reset').onclick = async () => {
  if (!confirm('সব কিছু মুছে নতুন করে শুরু করবেন?\n\nনম্বর, মেসেজ, ফাইল ও চলমান পাঠানো সব মুছে যাবে।')) return;
  try { await chrome.runtime.sendMessage({ type: 'reset' }); } catch (e) {}
  $('got').value = ''; $('nums').value = ''; $('msg').value = '';
  $('min').value = 20; $('max').value = 60; $('limit').value = 50; $('cc').value = '880';
  $('file').value = ''; $('extnote').textContent = '';
  const sel = $('lbl'); sel.textContent = ''; sel.append(new Option('আগে লেবেল লোড করুন', '')); sel.disabled = true; $('lblget').disabled = true;
  $('cnt').textContent = ''; $('gotcnt').textContent = '';
  cur = null; $('live').style.display = 'none'; $('status').textContent = '';
  showAtt();
  showPage('p1');
};
