// WhatsApp পেজের নিজস্ব জগতে (MAIN world) চলে। wa-js দিয়ে লেবেল ও চ্যাট পড়ে, ফল content.js-কে পাঠায়।
(() => {
  if (window.__cmBridge) return;
  window.__cmBridge = true;

  const reply = (id, data) => window.postMessage({ cm: 'res', id, ...data }, '*');

  async function ready() {
    for (let i = 0; i < 60; i++) {
      if (window.WPP && window.WPP.isReady) return true;
      await new Promise(r => setTimeout(r, 500));
    }
    return false;
  }

  const clean = s => String(s || '').replace(/[\n,]/g, ' ').trim();

  async function phoneOf(wid) {
    if (!wid) return null;
    if (wid.server === 'c.us') return wid.user;
    if (wid.server === 'lid') {
      try {
        const e = await WPP.contact.getPnLidEntry(wid);
        const p = e && e.phoneNumber && (e.phoneNumber.id || String(e.phoneNumber._serialized || '').split('@')[0]);
        if (p) return p;
      } catch (e) {}
    }
    return null;
  }

  async function run(op, arg) {
    if (!(await ready())) throw new Error('WhatsApp Web পুরোপুরি লোড হয়নি');
    if (op === 'labels') {
      const labels = await WPP.labels.getAllLabels();
      return { labels: labels.map(l => ({ id: l.id, name: l.name, count: l.count })) };
    }
    if (op === 'labelNumbers') {
      const chats = await WPP.chat.list({ withLabels: [String(arg)], onlyUsers: true });
      const items = [];
      let hidden = 0;
      for (const c of chats) {
        const phone = await phoneOf(c.id);
        if (!phone) { hidden++; continue; }
        const ct = c.contact || {};
        let name = clean(ct.name || ct.shortName || ct.pushname || '');
        if (/^\+?[\d\s\-()]{9,}$/.test(name)) name = '';
        items.push({ phone, name });
      }
      return { items, total: chats.length, hidden };
    }
    if (op === 'allNumbers') {
      const prefix = String(arg || '').replace(/\D/g, '');
      const map = new Map();
      let hidden = 0, other = 0;
      const add = async (wid, rawName) => {
        const phone = await phoneOf(wid);
        if (!phone) { hidden++; return; }
        if (prefix && !phone.startsWith(prefix)) { if (!map.has(phone)) other++; return; }
        let name = clean(rawName);
        if (/^\+?[\d\s\-()]{9,}$/.test(name)) name = '';
        const old = map.get(phone);
        if (old === undefined || (!old && name)) map.set(phone, name);
      };
      for (const c of await WPP.chat.list({ onlyUsers: true })) {
        const ct = c.contact || {};
        await add(c.id, ct.name || ct.shortName || ct.pushname || '');
      }
      for (const ct of await WPP.contact.list({ onlyMyContacts: true })) {
        if (ct.isUser === false) continue;
        await add(ct.id, ct.name || ct.shortName || ct.pushname || '');
      }
      return { items: [...map].map(([phone, name]) => ({ phone, name })), hidden, other };
    }
    throw new Error('অজানা কাজ');
  }

  window.addEventListener('message', async ev => {
    const d = ev.data;
    if (ev.source !== window || !d || d.cm !== 'req') return;
    try { reply(d.id, { ok: true, ...(await run(d.op, d.arg)) }); }
    catch (e) { reply(d.id, { ok: false, err: String((e && e.message) || e) }); }
  });
})();
