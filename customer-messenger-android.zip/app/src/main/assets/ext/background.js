// আইকনে চাপলে সাইড প্যানেল খোলে (পপআপের মতো বন্ধ হয় না)
if (chrome.sidePanel) chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
else chrome.action.onClicked.addListener(() => chrome.windows.create({ url: 'popup.html', type: 'popup', width: 440, height: 760 }));

const rand = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
const save = st => chrome.storage.local.set({ st });
async function S() { const { st } = await chrome.storage.local.get('st'); return st || { running: false, queue: [], idx: 0 }; }
async function daily() {
  const today = new Date().toDateString();
  const { d } = await chrome.storage.local.get('d');
  return d && d.date === today ? d : { date: today, count: 0 };
}

let busy = false;
async function go() {
  if (busy) return; busy = true;
  try {
    const st = await S();
    if (!st.running) return;
    if (st.nextAt > Date.now() + 1000) return; // আগের কাজ চলছে, দ্বিতীয়বার শুরু নয়
    if (st.idx >= st.queue.length) { st.running = false; st.note = 'সব মেসেজ শেষ'; await save(st); return; }
    const d = await daily();
    if (d.count >= st.limit) { st.running = false; st.note = 'আজকের সীমা শেষ'; await save(st); return; }
    const it = st.queue[st.idx];
    it.status = 'sending'; st.at = Date.now(); st.nextAt = 9e15; // Infinity JSON-এ null হয়ে যায়, তাই বড় সংখ্যা
    const url = `https://web.whatsapp.com/send?phone=${it.phone}` + (st.hasAtt ? '' : `&text=${encodeURIComponent(it.text)}`);
    let ok = false;
    if (st.tabId) { try { await chrome.tabs.update(st.tabId, { url, active: true }); ok = true; } catch (e) {} }
    if (!ok) {
      // আগে থেকে খোলা WhatsApp Web ট্যাব থাকলে সেটাই ব্যবহার। নতুন ট্যাব খুললে "অন্য উইন্ডোতে খোলা আছে" সমস্যায় ফাঁকা পেজ বা লগইন সমস্যা হয়
      try {
        const open = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
        if (open.length) { await chrome.tabs.update(open[0].id, { url, active: true }); st.tabId = open[0].id; ok = true; }
      } catch (e) {}
    }
    if (!ok) { const t = await chrome.tabs.create({ url }); st.tabId = t.id; }
    await save(st);
  } finally { busy = false; }
}

async function tick() {
  const st = await S();
  if (st.running && Date.now() >= st.nextAt - 500) go();
}
chrome.alarms.onAlarm.addListener(tick);

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === 'start') {
      const queue = m.items.map(i => ({ phone: i.phone, name: i.name, text: m.text.split('{name}').join(i.name || 'গ্রাহক'), status: 'pending' }));
      await save({ running: true, queue, idx: 0, min: m.min, max: m.max, limit: m.limit, hasAtt: !!m.hasAtt, nextAt: 0, note: '' });
      go(); reply({ ok: true });
    } else if (m.type === 'stop') {
      const st = await S(); st.running = false; st.note = 'আপনি বন্ধ করেছেন';
      st.queue.forEach(i => { if (i.status === 'sending') i.status = 'pending'; });
      await save(st); chrome.alarms.clear('tick'); reply({ ok: true });
    } else if (m.type === 'reset') {
      chrome.alarms.clear('tick');
      await chrome.storage.local.remove(['st', 'att', 'form', 'got']);
      reply({ ok: true });
    } else if (m.type === 'getJob') {
      const st = await S(); const it = st.queue[st.idx];
      reply(st.running && it && it.status === 'sending' && Date.now() - st.at < 90000 ? { phone: it.phone, text: it.text, hasAtt: !!st.hasAtt } : null);
    } else if (m.type === 'result') {
      const st = await S(); const it = st.queue[st.idx];
      if (!st.running || !it || it.status !== 'sending') return reply({});
      it.status = m.ok ? 'sent' : 'failed'; if (!m.ok) it.why = m.why || '';
      if (m.ok) { const d = await daily(); d.count++; await chrome.storage.local.set({ d }); }
      st.idx++;
      if (st.idx >= st.queue.length) { st.running = false; st.note = 'সব মেসেজ শেষ'; await save(st); return reply({}); }
      const delay = rand(st.min, st.max) * 1000;
      st.delay = delay;
      st.nextAt = Date.now() + delay;
      await save(st);
      chrome.alarms.create('tick', { when: st.nextAt });
      setTimeout(tick, delay);
      reply({});
    }
  })();
  return true;
});
